# General Management API

Framework: express
